<?php
/**
 * Joomla! component Dynamic404
 *
 * @author      Yireo (http://www.yireo.com/)
 * @package     Dynamic404
 * @copyright   Copyright (c) 2013 Yireo (http://www.yireo.com/)
 * @license     GNU Public License (GPL) version 3 (http://www.gnu.org/licenses/gpl-3.0.html)
 * @link        http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// GUI elements
JHTML::_('behavior.tooltip');
?>
<form method="post" name="adminForm" id="adminForm" action="index.php">
<table cellspacing="0" cellpadding="0" border="0" width="100%">
<tr>
<td width="50%" valign="top">
    <fieldset class="adminform">
        <legend><?php echo JText::_( 'System Template' ); ?></legend>
        <table class="admintable">
        <tr>
            <td width="100" align="right" class="key">
                <?php echo JText::_( 'Patch' ); ?>
            </td>
            <td>
                <?php if ($this->patch) { ?>
                    <?php echo $this->getMessageText('Patch applied', 
                        'The System Template (/templates/system/) already contains the Dynamic404 error.php-file.', 0); ?>
                <?php } else { ?>
                    <?php echo $this->getMessageText('No patch applied', 
                        'The System Template does not yet contain the Dynamic404 error.php-file. '
                        . 'You will need to patch it before you can make use of Dynamic404.', -2 ); ?>
                <?php } ?>
            </td>
        </tr>
        <tr>
            <td width="100" align="right" class="key">
                <?php echo JText::_( 'Backup' ); ?>
            </td>
            <td>
                <?php if ($this->backup) { ?>
                    <?php echo $this->getMessageText('Backup available', 
                        'The System Template contains a backup of the original error.php file. ' .
                        'This guarantees a flawless functioning when you decide to remove Dynamic404.', 0); ?>
                <?php } else { ?>
                    <?php echo $this->getMessageText('No backup available', 
                        'The System Template does not contain a Dynamic404 backup of the original error.php file. ' .
                        'You either need to patch to make use of Dynamic404 or restore your backup from another place.', -1); ?>
                <?php } ?>
            </td>
            </td>
        </tr>
        </table>
    </fieldset>
</td>
</tr>
<tr>
<td width="50%" valign="top">
    <fieldset class="adminform">
        <legend><?php echo JText::_( 'Joomla! templates' ); ?></legend>
        <table class="admintable">
        <?php if (!empty($this->templates)) { ?>
        <?php foreach ($this->templates as $template) { ?>
        <tr>
            <td width="100" align="right" class="key">
                <?php echo $template->name; ?>
            </td>
            <td>
                <?php echo $template->message; ?>
            </td>
        </tr>
        <?php } ?>
        <?php } else { ?>
        <tr>
            <td colspan="2">
                <?php echo JText::_('No templates found'); ?>
            </td>
        </tr>
        <?php } ?>
        </table>
    </fieldset>
</td>
</tr>
</table>

<input type="hidden" name="option" value="com_dynamic404" />
<input type="hidden" name="view" value="setup" />
<input type="hidden" name="task" value="" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>
