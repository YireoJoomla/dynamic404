<?php
/**
 * Joomla! component Dynamic404
 *
 * @author      Yireo (http://www.yireo.com/)
 * @package     Dynamic404
 * @copyright   Copyright (c) 2013 Yireo (http://www.yireo.com/)
 * @license     GNU Public License (GPL) version 3 (http://www.gnu.org/licenses/gpl-3.0.html)
 * @link        http://www.yireo.com/
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Load the Yireo library
require_once (JPATH_COMPONENT.'/lib/loader.php');

// Load the helpers
require_once (JPATH_COMPONENT.'/helpers/core.php');
require_once (JPATH_COMPONENT.'/helpers/acl.php');
require_once (JPATH_COMPONENT.'/helpers/gui.php');

// Make sure the user is authorized to view this page
if (Dynamic404HelperAcl::isAuthorized() == false) {
    $application = JFactory::getApplication();
	$application->redirect( 'index.php', JText::_('ALERTNOTAUTH') );
}

// Definitions
define( 'DYNAMIC404_ERROR_PATCH', JPATH_ADMINISTRATOR.'/components/com_dynamic404/lib/error.php' );
define( 'DYNAMIC404_ERROR_TARGET', JPATH_SITE.'/templates/system/error.php' );
define( 'DYNAMIC404_ERROR_BACKUP', JPATH_SITE.'/templates/system/error.before-dynamic404.php' );

// Require the base controller
require_once (JPATH_COMPONENT.'/controller.php');
$controller	= new Dynamic404Controller( );

// Perform the Request task
$controller->execute( JRequest::getCmd('task'));
$controller->redirect();

