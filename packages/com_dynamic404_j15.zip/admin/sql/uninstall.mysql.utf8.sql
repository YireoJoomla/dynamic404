DROP TABLE IF EXISTS `#__dynamic404_logs`;
DROP TABLE IF EXISTS `#__dynamic404_redirects`;