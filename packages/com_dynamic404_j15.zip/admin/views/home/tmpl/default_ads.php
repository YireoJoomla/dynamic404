<?php
/*
 * Joomla! component Dynamic404
 *
 * @author Yireo (info@yireo.com)
 * @package Dynamic404
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

defined('_JEXEC') or die('Restricted access');
?>
<h2 class="promotion_header"><?php echo JText::_('Yireo focus'); ?></h2>
<div id="promotion">
    <?php if ($this->backend_feed == 1) : ?>
    <div class="loader" />
    <?php else: ?>
    <?php echo JText::_('Advertizement is disabled'); ?>
    <?php endif; ?>
    </div>
</div>
<h2 class="latest_news_header"><?php echo JText::_('Latest blog from Yireo'); ?></h2>
<div id="latest_news">
    <?php if ($this->backend_feed == 1) : ?>
    <div class="loader" />
    <?php else: ?>
    <?php echo JText::_('RSS-feed is disabled'); ?>
    <?php endif; ?>
</div>

</td>
