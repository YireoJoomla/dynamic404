<?php
/*
 * Joomla! component Dynamic404
 *
 * @author Yireo (info@yireo.com)
 * @package Dynamic404
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

defined('_JEXEC') or die('Restricted access');
?>
<?php foreach ($this->icons as $icon) : ?>
<div style="float:left">
    <div class="icon">
        <a href="<?php echo $icon['link']; ?>" target="<?php echo $icon['target']; ?>"><?php echo $icon['icon']; ?><span><?php echo $icon['text']; ?></span></a>
    </div>
</div>
<?php endforeach; ?>
<div style="clear:both;" />
