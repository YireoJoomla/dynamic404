<?php
/**
 * Joomla! component Dynamic404
 *
 * @author Yireo
 * @package Dynamic404
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('JPATH_BASE') or die;

// Initialize the ACLs
Dynamic404HelperAcl::init();

/*
 * Helper for ACL-permissions
 */
class Dynamic404HelperAcl
{
    /*
     * Initialize the helper-class
     *
     * @param mixed $string
     * @return string
     */
    static public function init()
    {
        // Joomla! 1.5 ACLs
        if(Dynamic404HelperCore::isJoomla15()) {
            $auth = JFactory::getACL();
            $auth->addACL('com_dynamic404', 'manage', 'users', 'super administrator');
            $auth->addACL('com_dynamic404', 'manage', 'users', 'administrator');
            $auth->addACL('com_dynamic404', 'manage', 'users', 'manager');
        }
    }
    
    /*
     * Check whether a certain person is authorised
     *
     * @param mixed $string
     * @return string
     */
    static public function isAuthorized()
    {
        // Initialize system variables
        $user = JFactory::getUser();

        // Check the ACLs for Joomla! 1.5
        if (Dynamic404HelperCore::isJoomla15()) {
            if($user->authorize( 'com_dynamic404', 'manage' )) {
                return true;
            } else {
                return false;
            }

        // Check the ACLs for Joomla! 2.5 or later
        } else if($user->authorise('com_dynamic404.manage')) {
            return true;
        }
        
        return false;
    }
}


