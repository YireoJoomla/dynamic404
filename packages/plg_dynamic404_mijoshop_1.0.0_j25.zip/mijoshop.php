<?php
/**
 * Joomla! plugin for Dynamic404 - MijoShop
 *
 * @author      Yireo (http://www.yireo.com/)
 * @package     Dynamic404
 * @copyright   Copyright (c) 2013 Yireo (http://www.yireo.com/)
 * @license     GNU Public License (GPL) version 3 (http://www.gnu.org/licenses/gpl-3.0.html)
 * @link        http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

// Import the parent class
jimport( 'joomla.plugin.plugin' );

/**
 * Dynamic404 Plugin for MijoShop 
 */
class plgDynamic404Mijoshop extends JPlugin
{
    /**
     * Load the parameters
     * 
     * @access private
     * @param null
     * @return JParameter
     */
    private function getParams()
    {
        return $this->params;
    }

    /**
     * Determine whether this plugin could be used
     * 
     * @access private
     * @param null
     * @return boolean
     */
    private function isEnabled()
    {
        if(!is_dir(JPATH_SITE.'/components/com_mijoshop')) {
            return false;
        }

        $mijoshop = JPATH_ROOT.'/components/com_mijoshop/mijoshop/mijoshop.php';
        $library = JPATH_ROOT.'/components/com_mijoshop/opencart/config.php';
        if (!file_exists($mijoshop) or !file_exists($library)) {
            return false;
        }

        require_once($mijoshop);

        return true;
    }

    /**
     * Return all possible matches
     *
     * @access public
     * @param string $urilast
     * @return array
     */
    public function getMatches($urilast = null)
    {
        $matches = array();
        if($this->isEnabled() == false) {
            return $matches;
        }

        $rows = $this->getItems($urilast);
        if(!empty($rows)) {
            foreach( $rows as $row ) {

                $row = $this->prepareItem($row);
                if(empty($row)) {
                    continue;
                }

                $matches[] = $row;
            }
        }

        return $matches;
    }

    /**
     * Get all MijoShop items
     *
     * @access public
     * @param string $alias
     * @return array
     */
    public function getItems($alias)
    {
        static $rows = null;
        if(empty($rows)) {
            $db = JFactory::getDBO();
            $alias = preg_replace('/^([0-9]+)-/', '', $alias);
            $db->setQuery('SELECT p.`product_id`, pd.`name`, pc.`category_id` FROM `#__mijoshop_product` AS p'
                . ' LEFT JOIN `#__mijoshop_product_description` AS pd ON pd.`product_id` = p.`product_id`'
                . ' LEFT JOIN `#__mijoshop_product_to_category` AS pc ON pc.`product_id` = p.`product_id`'
                . ' WHERE p.`status`=1 AND (pd.`name` LIKE "%'.$alias.'%" OR p.`product_id` = '.(int)$alias.')');
            $rows = $db->loadObjectList();

            if(!empty($rows)) { 
                foreach($rows as $index => $row) {
                    $row->id = $row->product_id;
                    $row->row_type = 'item';
                    $rows[$index] = $row;
                }
            }
        }

        return $rows;
    }

    /**
     * Method to prepare an item
     *
     * @access private
     * @param object $item
     * @return string
     */
    private function prepareItem($item)
    {
        // Check access for items
        /*if(isset($item->row_type) && $item->row_type == 'item') {
            $user = JFactory::getUser();
            $accessLevels = $user->getAuthorisedViewLevels();
            if(isset($item->access) && $item->access > 0 && !in_array($item->access, $accessLevels)) {
                return null;
            }
        }*/

        $item->type = 'component';
        $item->rating = $this->getParams()->get('rating', 85);
        $item->match_note = 'mijoshop item';

        switch($item->row_type) {
    
            case 'item':
            default:
                if(isset($item->category_id) && $item->category_id > 0) {
                    $route = 'index.php?route=product/product&path='.(int)$item->category_id.'&product_id='.(int)$item->id;
                } else {
                    $route = 'index.php?route=product/product&product_id='.(int)$item->id;
                }
                $item->url = MijoShop::get('router')->route($route);
                break;
        }
        return $item;
    }
}
