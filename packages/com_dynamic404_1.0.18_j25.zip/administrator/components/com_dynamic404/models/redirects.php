<?php
/**
 * Joomla! component Dynamic404
 *
 * @author Yireo
 * @package Dynamic404
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

class Dynamic404ModelRedirects extends YireoModel
{
	/**
	 * Constructor
     *
     * @access public
     * @param null
     * @return null
	 */
	public function __construct()
	{
        $this->_search = array('match', 'url');
		parent::__construct('redirect');
	}
}
