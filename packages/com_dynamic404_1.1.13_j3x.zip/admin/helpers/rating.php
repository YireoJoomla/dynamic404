<?php
/**
 * Joomla! component Dynamic404
 *
 * @package    Dynamic404
 * @author     Yireo <info@yireo.com>
 * @copyright  Copyright 2016 Yireo (https://www.yireo.com/)
 * @license    GNU Public License (GPL) version 3 (http://www.gnu.org/licenses/gpl-3.0.html)
 * @link       https://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

/**
 * Class Dynamic404HelperRating
 */
class Dynamic404HelperRating
{
	/**
	 * Method to match one string with another
	 *
	 * @param   string $text1 String to match
	 * @param   string $text2 String to compare with
	 *
	 * @return bool
	 */
	public function matchTextString($text1, $text2)
	{
		$text1 = strtolower($text1);
		$text2 = strtolower($text2);

		if ($text1 == $text2 || strstr($text1, $text2) || strstr($text2, $text1))
		{
			return true;
		}

		return false;
	}

	/**
	 * Method to match certain text parts, chopping a string into parts using a dash (-)
	 *
	 * @param   string $text1 String to match
	 * @param   string $text2 String to compare with
	 *
	 * @return array
	 */
	public function matchTextParts($text1, $text2)
	{
		$text1 = strtolower($text1);
		$text2 = strtolower($text2);

		$text1_parts = explode('-', $text1);
		$text2_parts = explode('-', $text2);

		$match_parts = array();

		if (!empty($text1_parts))
		{
			foreach ($text1_parts as $text1_part)
			{
				if (in_array($text1_part, $text2_parts))
				{
					$match_parts[] = $text1_part;
				}
			}
		}

		return $match_parts;
	}
}