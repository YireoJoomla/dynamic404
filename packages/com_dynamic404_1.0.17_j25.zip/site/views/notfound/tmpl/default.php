<?php
/**
 * Joomla! component Dynamic404
 *
 * @author      Yireo (http://www.yireo.com/)
 * @package     Dynamic404
 * @copyright   Copyright (c) 2013 Yireo (http://www.yireo.com/)
 * @license     GNU Public License (GPL) version 3 (http://www.gnu.org/licenses/gpl-3.0.html)
 * @link        http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

?>
<h2><?php echo $this->title; ?></h2>

<p>
    <?php if (!empty($this->matches)) : ?>
    <?php echo JText::_( 'The following matches were found' ); ?>:
    <ul>
        <?php foreach ($this->matches as $item) : ?>
        <li><a href="<?php echo $item->url; ?>"><?php echo $item->name; ?></a> (<?php echo $item->rating; ?>%)</li>
        <?php endforeach; ?>
    </ul>
    <?php else: ?>
        <?php echo JText::_('No matches found'); ?>
    <?php endif; ?>
</p>

<p>
    <?php echo JText::_( 'Alternative actions' ); ?>:
	<ul>
		<li><a href="<?php echo JURI::base(); ?>" title="<?php echo JText::_('Go to the home page'); ?>"><?php echo JText::_('Home Page'); ?></a></li>
		<li><a href="<?php echo JRoute::_( 'index.php?option=com_search&searchword='.$this->urilast ); ?>" title="<?php echo JText::_('Search'); ?>"><?php echo JText::_('Search for'); ?>: <?php echo $this->urilast; ?></a></li>
	</ul>
</p>
<p>
    <?php echo JText::_('If difficulties persist, please contact the system administrator of this site.'); ?>
</p>
