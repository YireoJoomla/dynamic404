<?php
/*
 * Joomla! Yireo Lib
 *
 * @author Yireo (info@yireo.com)
 * @package YireoLib
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 * @version 0.5.1
 */

defined('_JEXEC') or die('Restricted access');
?>
<?php if(!empty($this->params)): ?>
<?php echo $this->params->render(); ?>
<?php else: ?>
<?php endif; ?>
