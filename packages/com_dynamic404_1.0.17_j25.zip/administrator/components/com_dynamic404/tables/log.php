<?php
/**
 * Joomla! component Dynamic404
 *
 * @author Yireo
 * @package Dynamic404
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com/
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
* Dynamic404 Table class
*/
class TableLog extends YireoTable
{
	/**
	 * Constructor
     *
     * @access public
     * @param JDatabase $db
     * @return null
	 */
	public function __construct(& $db) 
    {
        // Initialize the fields
        $this->_fields = array( 
            'log_id' => null,
            'request' => null,
            'timestamp' => null,
            'hits' => null,
        );

        // Set the required fields
        $this->_required = array( 'request', 'timestamp' );

        // Call the constructor
		parent::__construct('#__dynamic404_logs', 'log_id', $db);
	}
}
