<?php
/**
 * Joomla! component Dynamic404
 *
 * @author      Yireo (http://www.yireo.com/)
 * @package     Dynamic404
 * @copyright   Copyright (c) 2013 Yireo (http://www.yireo.com/)
 * @license     GNU Public License (GPL) version 3 (http://www.gnu.org/licenses/gpl-3.0.html)
 * @link        http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

JHTML::_('behavior.tooltip');
?>

<style type="text/css">
	table.paramlist td.paramlist_key {
		width: 92px;
		text-align: left;
		height: 30px;
	}
</style>

<form method="post" name="adminForm" id="adminForm">
<div class="col50">
	<fieldset class="adminform">
		<legend><?php echo JText::_( '404 Match' ); ?></legend>
		<table class="admintable" width="100%">
		<tr>
			<td width="100" align="right" class="key">
				<label for="match">
					<?php echo JText::_( 'Match' ); ?>:
				</label>
			</td>
			<td class="value">
				<input class="text_area" type="text" name="match" id="match" size="100" maxlength="250" value="<?php echo $this->item->match;?>" />
                    <?php echo $this->getMessageText(null, 'The URL segment or full URL to match. '
                    . 'What you need to enter here depends on the Match Type you set below. '
                    . 'The URL referenced here is the URL that throws the 404 Not Found message.' ); ?>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="type">
				    <?php echo JText::_( 'Match Type' ); ?>:
				</label>
			</td>
			<td class="value">
				<?php echo $this->lists['type']; ?>
			</td>
		</tr>
        </table>
    </fieldset>
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Destination' ); ?></legend>
		<table class="admintable" width="100%">
		<tr>
			<td width="100" align="right" class="key">
				<label for="url">
					<?php echo JText::_( 'Destination URL' ); ?>:
				</label>
			</td>
			<td class="value">
				<input class="text_area" type="text" name="url" id="url" size="100" maxlength="250" value="<?php echo $this->item->url;?>" />
                <?php echo $this->getMessageText(null, 'The destination URL to redirect to. '.
                    'This could be an absolute URL including htttp:// or a relative Joomla! SEF URL.' ); ?>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="http_status">
				    <?php echo JText::_( 'HTTP Status' ); ?>:
				</label>
			</td>
			<td class="value">
				<?php echo $this->lists['http_status']; ?>
			</td>
		</tr>
        </table>
    </fieldset>
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'Other settings' ); ?></legend>
		<table class="admintable" width="100%">
		<tr>
			<td width="100" align="right" class="key">
				<label for="description">
					<?php echo JText::_( 'Description' ); ?>:
				</label>
			</td>
			<td class="value">
				<input class="text_area" type="text" name="description" id="description" size="32" maxlength="250" value="<?php echo $this->item->description;?>" />
                <?php echo $this->getMessageText(null, 'A simple description for internal reference.'); ?>
			</td>
		</tr>
        <tr>
            <td valign="top" align="right" class="key">
                <?php echo JText::_( 'Published' ); ?>:
            </td>
            <td class="value">
                <?php echo $this->lists['published']; ?>
            </td>
        </tr>
        <tr>
            <td valign="top" align="right" class="key">
                <label for="ordering">
                    <?php echo JText::_( 'Ordering' ); ?>:
                </label>
            </td>
            <td class="value">
                <?php echo $this->lists['ordering']; ?>
            </td>
        </tr>
	</table>
	</fieldset>
</div>
<div class="clr"></div>

<input type="hidden" name="option" value="com_dynamic404" />
<input type="hidden" name="view" value="redirect" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="cid[]" value="<?php echo $this->item->redirect_id; ?>" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>
