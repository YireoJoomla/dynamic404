<?php
/**
 * Joomla! component Dynamic404
 *
 * @author Yireo
 * @package Dynamic404
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!  
defined('_JEXEC') or die();

// Definitions
define('DYNAMIC404_ERROR_PATCH', JPATH_ADMINISTRATOR.'/components/com_dynamic404/patch/error.php');
define('DYNAMIC404_ERROR_TARGET', JPATH_SITE.'/templates/system/error.php');
define('DYNAMIC404_ERROR_BACKUP', JPATH_SITE.'/templates/system/error.before-dynamic404.php');
 
// Restore the original backup
jimport('joomla.filesystem.file');
if (is_file(DYNAMIC404_ERROR_BACKUP) && md5_file(DYNAMIC404_ERROR_BACKUP) != md5_file(DYNAMIC404_ERROR_TARGET)) {
    $rt = JFile::move(DYNAMIC404_ERROR_BACKUP, DYNAMIC404_ERROR_TARGET);
}

