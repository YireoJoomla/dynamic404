<?php
/**
 * Joomla! component Dynamic404
 *
 * @author      Yireo (http://www.yireo.com/)
 * @package     Dynamic404
 * @copyright   Copyright (c) 2013 Yireo (http://www.yireo.com/)
 * @license     GNU Public License (GPL) version 3 (http://www.gnu.org/licenses/gpl-3.0.html)
 * @link        http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('JPATH_BASE') or die;

jimport('joomla.plugin.plugin');

/**
 * Plugin class for reusing redirection of the Dynamic404 component
 *
 * @package     Dynamic404
 * @subpackage    plgSystemDynamic404
 */
class plgSystemDynamic404 extends JPlugin
{
    /**
     * Constructor.
	 *
	 * @param object &$subject The object to observe.
	 * @param array $config An optional associative array of configuration settings.
	 * @return null
     */
    public function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);

        // Set the error handler for E_ERROR to be the class handleError method.
        if(JFactory::getApplication()->isSite()) {
            JError::setErrorHandling(E_ERROR, 'callback', array('plgSystemDynamic404', 'handleError'));
            set_exception_handler(array('plgSystemDynamic404', 'handleError'));
        }
    }

    /**
     * Method to catch Joomla! error-handling
	 *
	 * @param object &$error JError object
	 * @return null
     */
    static public function handleError(&$error)
    {
        // Get the application object.
        $application = JFactory::getApplication();
        $error = JError::getError();
            
        // Include the 404 Helper-class
        require_once JPATH_ADMINISTRATOR.'/components/com_dynamic404/helpers/helper.php';

        // Instantiate the helper with the argument of how many matches to show
        $helper = new Dynamic404Helper();

        // Make sure the error is a 404 and we are not in the administrator.
        if (!$application->isAdmin() and ($error->get('code') == 404)) {

            // Log the 404 entry
            $helper->log();

            // Get the possible matches
            $matches = $helper->getMatches();

            // Get the last segment - nice for searching
            $urilast = $helper->getLast();

            // Redirect to the first found match
            $helper->doRedirect();
        }

        // Render the error page.
        $params = JComponentHelper::getParams('com_dynamic404');
        if($params->get('error_page', 0) == 1) {
            JError::customErrorPage($error);

        } else {
            $helper->displayErrorPage($error);
            $application->close(0);
        }
    }

    /**
     * Method to be called after the Joomla! Application has been initialized
	 *
	 * @param null
	 * @return null
     */
    public function onAfterInitialise()
    {
        // Get the application object.
        $application = JFactory::getApplication();

        // Make sure we are not in the administrator.
        if ($application->isSite() == false) {
            return null;
        }

        // Redirect non-www to www
        $redirect_www = $this->params->get('redirect_www', 0);
        if($redirect_www == 1) {
            $uri = JURI::current();
            if(preg_match('/^(http|https)\:\/\/([^\/]+)(.*)/', $uri, $match)) {
                $hostname = $match[2];
                if(preg_match('/^www\./', $hostname) == false) {
                    $newUrl = $match[1].'://www.'.$hostname.$match[3];
                    header('HTTP/1.1 301 Moved Permanently');
                    header('Location: '.$newUrl);
                    $application->close();
                    exit;
                }
            }
        }

        // Test for non-existent components
        $uri = (isset($_SERVER['REQUEST_URI'])) ? $_SERVER['REQUEST_URI'] : null;
        if(preg_match('/\/component\/([a-zA-Z0-9\.\-\_]+)\//', $uri, $componentMatch)) {
            $component = preg_replace('/^com_/', '', $componentMatch[1]);
            if(!is_dir(JPATH_SITE.'/components/com_'.$component)) {

                // Fetch the last segment of this URL
                $segments = explode('/', $uri);
                $lastSegment = trim(array_pop($segments));
                if(empty($lastSegment)) $lastSegment = trim(array_pop($segments));

                // Strip the ID if possible
                if(preg_match('/^([0-9]+)(.*)/', $lastSegment, $lastSegmentMatch)) {
                    $lastSegment = $lastSegmentMatch[2];
                }
                
                // Redirect to this fake URL assuming it will trigger a 404-redirect
                $url = JURI::base().'component/content/'.$lastSegment;
                header('Location: '.$url);
                exit;
            }
        }

        /* 
         * @todo: Add setting to enable this behaviour
        if (false) {
        
            // Include the 404 Helper-class
            require_once JPATH_ADMINISTRATOR.'/components/com_dynamic404/helpers/helper.php';

            // Instantiate the helper with the argument of how many matches to show
            $helper = new Dynamic404Helper(false);

            // Get the possible matches
            $matches = $helper->getDirectMatches();

            // Redirect to the first found match
            if(!empty($matches)) {
                $helper->doRedirect();
            }
        }
        */
    }

    /**
     * Method to be called after the component has been rendered
	 *
	 * @param null
	 * @return null
     */
    public function onAfterRender()
    {
        $app = JFactory::getApplication();
        if(method_exists($app, 'getMessageQueue')) {
            $messageQueue = $app->getMessageQueue();
            if(!empty($messageQueue)) {
                foreach($messageQueue as $message) {
                    if($message['type'] != 'error') continue;
                    if(stristr($message['message'], JText::_('JGLOBAL_CATEGORY_NOT_FOUND'))) {
                        $errorCode = 404;
                        JError::raiseError($errorCode, $message['message']);
                    }
                }
            } 
        }
    }
}
