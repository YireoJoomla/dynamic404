<?php
/**
 * Joomla! plugin for Dynamic404 - VirtueMart 
 *
 * @author      Yireo (http://www.yireo.com/)
 * @package     Dynamic404
 * @copyright   Copyright (c) 2013 Yireo (http://www.yireo.com/)
 * @license     GNU Public License (GPL) version 3 (http://www.gnu.org/licenses/gpl-3.0.html)
 * @link        http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

// Import the parent class
jimport( 'joomla.plugin.plugin' );

/**
 * Dynamic404 Plugin for VirtueMart
 */
class plgDynamic404VirtueMart extends JPlugin
{
    /**
     * Load the parameters
     * 
     * @access private
     * @param null
     * @return JParameter
     */
    private function getParams()
    {
        jimport('joomla.version');
        $version = new JVersion();
        if(version_compare($version->RELEASE, '1.5', 'eq')) {
            $plugin = JPluginHelper::getPlugin('dynamic404', 'virtuemart');
            $params = new JParameter($plugin->params);
            return $params;
        } else {
            return $this->params;
        }
    }

    /**
     * Determine whether this plugin could be used
     * 
     * @access private
     * @param null
     * @return boolean
     */
    private function isEnabled()
    {
        if(!is_dir(JPATH_SITE.DS.'components'.DS.'com_virtuemart')) {
            return false;
        }
        return true;
    }

    /**
     * Return on all matches
     *
     * @access public
     * @param string $urilast
     * @return array
     */
    public function getMatches($urilast = null)
    {
        $matches = array();
        if($this->isEnabled() == false) {
            return $matches;
        }
        
        // Find a matching product
        $product = $this->findProduct(JRequest::getInt('product_id'));
        if(!empty($product)) $matches[] = $product;

        // Find a matching category
        $category = $this->findCategory(JRequest::getInt('category_id'));
        if(!empty($category)) $matches[] = $category;

        return $matches;
    }

    /**
     * Method to match possible products
     *
     * @access private
     * @param object $item
     * @return string
     */
    private function findCategory($category_id) 
    {
        $db = JFactory::getDBO();

        $query = "SELECT * FROM `#__vm_category` WHERE `category_id`=".(int)$category_id." LIMIT 0,1";
        $db->setQuery( $query );
        $category = $db->loadObject();
        $category->match_note = 'virtuemart category';
        if(empty($category)) {
            return null;
        }

        $category->type = 'component';
        $category->name = $category->category_name;
        $category->rating = $this->getParams()->get('rating', 85) - 1;
        $category->url = JRoute::_('index.php?page=shop.browse&category_id='.$category_id);
        return $category;
    }

    /**
     * Method to match possible products
     *
     * @access private
     * @param object $item
     * @return string
     */
    private function findProduct($product_id) 
    {
        $db = JFactory::getDBO();

        $query = "SELECT p.`product_name`, x.`category_id` FROM `#__vm_product` AS p "
            . " LEFT JOIN `#__vm_product_category_xref` AS x ON x.`product_id` = p.`product_id` "
            . " WHERE p.`product_id`=".(int)$product_id." AND `product_publish`='Y' "
            . " LIMIT 0,1"
        ;

        $db->setQuery( $query );
        $product = $db->loadObject();
        if(empty($product)) {
            return null;
        }

        $category_id = $product->category_id;
        $product->type = 'component';
        $product->name = $product->product_name;
        $product->match_note = 'virtuemart product';
        $product->rating = $this->getParams()->get('rating', 85);
        $product->url = JRoute::_('index.php?page=shop.product_details&flypage=flypage.tpl&product_id='.$product_id.'&category_id='.$category_id);
        return $product;
    }
}
